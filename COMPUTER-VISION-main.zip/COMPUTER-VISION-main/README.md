# COMPUTER---VISION
Explored 2 results of Face Recognition by Humans:Nineteen Results All Computer
Vision Researchers Should Know About paper by using atleast 10 contemporary celebrity images.
Generated the needed image distortions to test my results.
Explored the following Results from the Research Paper
RESULT 1: Humans can recognize familiar faces in very low-resolution images.
RESULT 3: High-frequency information by itself is insufficient for good face recognition
performance.
I have made summarised finding of the results.

